import { useEffect } from "react";
import { Hero, Marquee, Nav, Problem } from "./sections/Top";
import {
  Accountability,
  Included,
  Testimonial,
  TrainingDay,
  WhoFor,
} from "./sections/Program";
import {
  About,
  FAQ,
  FitQuiz,
  Outcomes,
  RoiCalculator,
} from "./sections/Convince";
import { Delivery } from "./sections/Delivery";
import { Apply, Footer, StickyCTA } from "./sections/Close";
import { BookingModal } from "./components/BookingModal";
import { useView } from "./nav";
import { CartDrawer, DeckTeaser, ShopView } from "./shop/Shop";

function Home() {
  return (
    <>
      <Nav />
      <main>
        <Hero />
        <Marquee />
        <Problem />
        <Included />
        <TrainingDay />
        <Delivery />
        <Accountability />
        <DeckTeaser />
        <Testimonial />
        <WhoFor />
        <RoiCalculator />
        <About />
        <FitQuiz />
        <Outcomes />
        <FAQ />
        <Apply />
      </main>
      <Footer />
      <StickyCTA />
    </>
  );
}

const TITLES: Record<string, string> = {
  home: "The Accelerator Course | The Salon Dr.",
  shop: "Shop · 30 Days to Retail Confidence | The Salon Dr.",
  product: "30 Days to Retail Confidence | The Salon Dr.",
  checkout: "Checkout | The Salon Dr.",
  thanks: "Order confirmed | The Salon Dr.",
};

export default function App() {
  const view = useView();

  useEffect(() => {
    document.title = TITLES[view] ?? TITLES.home;
  }, [view]);

  return (
    <div className="min-h-screen bg-cream text-ink">
      {view === "home" ? <Home /> : <ShopView view={view} />}
      <CartDrawer />
      <BookingModal />
    </div>
  );
}
