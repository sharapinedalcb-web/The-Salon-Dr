import { useState, type FormEvent, type ReactNode } from "react";
import { navigate, type View } from "../nav";
import { openBooking } from "../booking";
import { BRAND } from "../brand";
import { DECK, GIST, money, type DeckCard } from "./data";
import {
  addToCart,
  cartQty,
  cartTotal,
  clearCart,
  closeCart,
  openCart,
  placeOrder,
  setQty,
  useCartLines,
  useCartOpen,
  useOrder,
} from "./cart";

function BagIcon() {
  return (
    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden>
      <path d="M6.5 8h11l-.8 12.2a1 1 0 0 1-1 .8H8.3a1 1 0 0 1-1-.8L6.5 8z" />
      <path d="M9 8V6.8A3 3 0 0 1 12 3.8 3 3 0 0 1 15 6.8V8" />
    </svg>
  );
}

export function ShopHeader() {
  const lines = useCartLines();
  const count = cartQty(lines);
  return (
    <header className="sticky top-0 z-40 border-b border-sand bg-cream/90 backdrop-blur-xl">
      <div className="mx-auto flex w-full max-w-6xl flex-nowrap items-center justify-between gap-3 px-5 py-3">
        <button
          onClick={() => navigate("home")}
          className="flex shrink-0 items-center gap-2.5 whitespace-nowrap"
        >
          <span className="grid h-10 w-10 shrink-0 place-items-center overflow-hidden rounded-full bg-white shadow-sm">
            <img src={BRAND.logo} alt="" className="h-8 w-8 object-contain" />
          </span>
          <span className="hidden items-baseline gap-2 whitespace-nowrap leading-none sm:flex">
            <span className="font-display text-[13px] font-semibold uppercase tracking-[0.1em]">
              The Salon Dr.
            </span>
            <span className="text-[9px] uppercase tracking-[0.14em] text-rose-deep">
              Shop
            </span>
          </span>
        </button>

        <nav className="flex shrink-0 flex-nowrap items-center gap-4">
          <button
            onClick={() => navigate("home")}
            className="hidden whitespace-nowrap text-sm font-medium text-ink/60 transition hover:text-rose-deep sm:inline"
          >
            The Course
          </button>
          <button
            onClick={() => navigate("shop")}
            className="whitespace-nowrap text-sm font-semibold text-ink"
          >
            Shop
          </button>
          <button
            onClick={openBooking}
            className="hidden whitespace-nowrap text-sm font-medium text-ink/60 transition hover:text-rose-deep md:inline"
          >
            Book a call
          </button>
          <button
            onClick={openCart}
            aria-label={`Bag, ${count} items`}
            className="relative grid h-11 w-11 place-items-center rounded-full border border-ink/15 bg-white transition hover:border-rose"
          >
            <BagIcon />
            {count > 0 && (
              <span className="absolute -right-1 -top-1 grid h-5 min-w-5 place-items-center rounded-full bg-rose px-1 text-[10px] font-semibold text-ink">
                {count}
              </span>
            )}
          </button>
        </nav>
      </div>
    </header>
  );
}

function CardSpread({ compact = false }: { compact?: boolean }) {
  const place = [
    "left-[4%] top-8 -rotate-[7deg]",
    "left-1/2 top-1 z-10 -translate-x-1/2",
    "right-[4%] top-9 rotate-[7deg]",
  ];
  return (
    <div
      className={`relative mx-auto w-full max-w-[480px] ${
        compact ? "h-[320px] sm:h-[380px]" : "h-[360px] sm:h-[460px]"
      }`}
    >
      {GIST.map((card, i) => (
        <img
          key={card.id}
          src={card.front}
          alt={i === 1 ? `${DECK.name} deck, cards spread` : ""}
          className={`absolute w-[46%] max-w-[210px] rounded-2xl shadow-[0_28px_50px_-22px_rgba(33,33,33,0.55)] ${place[i]}`}
          draggable={false}
        />
      ))}
    </div>
  );
}

function FlipCard({ card }: { card: DeckCard }) {
  const [flipped, setFlipped] = useState(false);
  return (
    <figure className="w-full">
      <button
        type="button"
        onClick={() => setFlipped((f) => !f)}
        aria-pressed={flipped}
        className="w-full rounded-[1.15rem] text-left focus:outline-none focus-visible:ring-2 focus-visible:ring-rose focus-visible:ring-offset-4"
      >
        <div className="flip-scene">
          <div className={`flip-inner ${flipped ? "is-flipped" : ""}`}>
            <img
              src={card.front}
              alt={`${card.name} — front`}
              className="flip-face"
              draggable={false}
            />
            <img
              src={card.back}
              alt={`${card.name} — ${card.prompt}`}
              className="flip-face flip-back"
              draggable={false}
            />
          </div>
        </div>
      </button>
      <figcaption className="mt-4 px-1 text-center">
        <div className="font-display text-lg font-medium">{card.name}</div>
        <div className="mt-1 text-[11px] font-semibold uppercase tracking-[0.16em] text-rose-deep">
          {flipped ? "Back · tap to return" : "Tap to turn over"}
        </div>
      </figcaption>
    </figure>
  );
}

function Qty({
  value,
  onChange,
}: {
  value: number;
  onChange: (n: number) => void;
}) {
  return (
    <div className="inline-flex items-center rounded-full border border-sand bg-white">
      <button
        type="button"
        onClick={() => onChange(Math.max(1, value - 1))}
        className="grid h-11 w-11 place-items-center text-lg text-ink/70"
        aria-label="Decrease quantity"
      >
        −
      </button>
      <span className="w-6 text-center text-sm font-semibold">{value}</span>
      <button
        type="button"
        onClick={() => onChange(Math.min(10, value + 1))}
        className="grid h-11 w-11 place-items-center text-lg text-ink/70"
        aria-label="Increase quantity"
      >
        +
      </button>
    </div>
  );
}

export function ShopHome() {
  return (
    <div className="bg-cream">
      <ShopHeader />
      <div className="mx-auto w-full max-w-6xl px-5 pb-24 pt-14 md:pt-20">
        <div className="max-w-2xl">
          <span className="inline-flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.25em] text-rose-deep">
            <span className="h-px w-8 bg-rose/60" />
            The shop
          </span>
          <h1 className="mt-5 font-display-light text-4xl leading-tight sm:text-6xl">
            One product.
            <br />
            On purpose.
          </h1>
          <p className="mt-5 max-w-xl text-lg text-ink/65">
            Training day starts the habit. This deck is what keeps it alive at
            8:45 every morning — with or without Sonia in the room.
          </p>
        </div>

        <article className="mt-12 overflow-hidden rounded-[2rem] border border-sand bg-white shadow-[0_40px_80px_-50px_rgba(33,33,33,0.45)]">
          <div className="grid items-center lg:grid-cols-2">
            <div className="flex items-center justify-center bg-sand/50 px-4 py-8 md:py-12">
              <CardSpread />
            </div>

            <div className="p-8 md:p-12">
              <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-rose-deep">
                Card deck · Physical
              </div>
              <h2 className="mt-3 font-display-light text-4xl leading-tight">
                {DECK.name}
              </h2>
              <p className="mt-2 font-display text-lg text-ink/55">{DECK.tagline}</p>
              <div className="mt-5 font-display text-3xl font-semibold">
                {money(DECK.price)}
                <span className="ml-2 text-sm font-normal text-ink/45">AUD</span>
              </div>
              <p className="mt-5 text-ink/70">{DECK.blurb}</p>
              <div className="mt-8 flex flex-wrap gap-3">
                <button
                  onClick={() => navigate("product")}
                  className="rounded-full bg-ink px-7 py-4 text-sm font-semibold text-cream transition hover:bg-rose hover:text-ink"
                >
                  View the deck →
                </button>
                <button
                  onClick={() => addToCart(1)}
                  className="rounded-full border border-ink/20 px-7 py-4 text-sm font-semibold transition hover:border-ink"
                >
                  Add to bag
                </button>
              </div>
              <p className="mt-5 whitespace-nowrap text-[11px] leading-none tracking-tight text-ink/45">
                Complimentary shipping across Australia · One deck runs the whole team’s huddle
              </p>
            </div>
          </div>
        </article>
      </div>
    </div>
  );
}

export function ProductPage() {
  const [qty, setLocalQty] = useState(1);
  const [open, setOpen] = useState<string | null>("inside");

  const details: [string, string, ReactNode][] = [
    [
      "inside",
      "What’s in the box",
      "One physical deck for the whole team. Each morning someone turns a card and the huddle answers it: yesterday’s wins, today’s three priorities, and one stretch for the day. Keep it on the back bar. Five minutes, then the first client.",
    ],
    [
      "ship",
      "Shipping",
      "Complimentary shipping on every deck, anywhere in Australia. Packed flat so it arrives ready for Monday’s huddle. Most orders arrive in 5–8 business days, with a confirmation email the moment it leaves.",
    ],
    [
      "course",
      "How it pairs with the course",
      "On Accelerator Course day, Sonia installs the Daily Huddle. This deck is that huddle in card form, so it survives the week she leaves. Use it before the course to warm the team, or after to lock the habit in. The 30-day accountability session reviews exactly what these cards ask.",
    ],
  ];

  return (
    <div className="bg-cream pb-24">
      <ShopHeader />
      <div className="mx-auto w-full max-w-6xl px-5 pt-8">
        <button
          onClick={() => navigate("shop")}
          className="text-xs font-semibold uppercase tracking-[0.16em] text-ink/45 transition hover:text-rose-deep"
        >
          ← Shop
        </button>

        <div className="mt-6 grid items-start gap-10 lg:grid-cols-[0.85fr_1.15fr]">
          <div className="lg:sticky lg:top-28">
            <div className="rounded-[2rem] bg-sand/40 px-3 py-8">
              <CardSpread />
            </div>

          </div>

          <div>
            <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-rose-deep">
              The Salon Dr. · Card deck
            </div>
            <h1 className="mt-3 font-display-light text-4xl leading-tight sm:text-5xl">
              {DECK.name}
            </h1>
            <p className="mt-3 text-lg text-ink/60">{DECK.tagline}</p>
            <div className="mt-5 flex items-end gap-3">
              <span className="font-display text-4xl font-semibold">
                {money(DECK.price)}
              </span>
              <span className="mb-1 text-sm text-ink/45">AUD · GST inclusive</span>
            </div>

            <div className="mt-6 space-y-4 text-ink/75">
              <p>
                Most retail training evaporates by Wednesday. This deck doesn’t
                let it.
              </p>
              <p>
                Every morning, before the first client sits down, someone turns
                a card over and the team answers it out loud. No scripts. No one
                standing at the front of the room. Five minutes, and the
                confidence is practised — not hoped for.
              </p>
            </div>

            <div className="mt-7 flex flex-wrap items-center gap-4">
              <Qty value={qty} onChange={setLocalQty} />
              <button
                onClick={() => addToCart(qty)}
                className="rounded-full bg-ink px-8 py-4 text-sm font-semibold text-cream transition hover:bg-rose hover:text-ink"
              >
                Add to bag — {money(DECK.price * qty)}
              </button>
            </div>

            <ul className="mt-6 grid gap-2 text-sm text-ink/60 sm:grid-cols-3">
              <li>✓ Free shipping in Australia</li>
              <li>✓ Arrives in 5–8 days</li>
              <li>✓ One deck, whole team</li>
            </ul>

            <div className="mt-8 divide-y divide-sand border-y border-sand">
              {details.map(([id, title, body]) => (
                <div key={id}>
                  <button
                    onClick={() => setOpen(open === id ? null : id)}
                    className="flex w-full items-center justify-between py-4 text-left"
                  >
                    <span className="font-display text-lg">{title}</span>
                    <span className={`text-ink/40 ${open === id ? "rotate-45" : ""}`}>
                      +
                    </span>
                  </button>
                  {open === id && (
                    <p className="pb-4 text-sm leading-relaxed text-ink/65">{body}</p>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Gist */}
        <section className="mt-20 rounded-[2rem] border border-sand bg-white px-5 py-12 md:px-12 md:py-16">
          <div className="mx-auto max-w-2xl text-center">
            <span className="rounded-full bg-sand px-3 py-1 text-[10px] font-semibold uppercase tracking-[0.22em] text-rose-deep">
              A gist
            </span>
            <h2 className="mt-5 font-display-light text-3xl leading-tight sm:text-5xl">
              Three cards from the deck. Turn them over.
            </h2>
            <p className="mt-4 text-ink/60">
              This is a taste, not the whole 30 days. The front names the
              ritual. The back is what your team actually says out loud. Tap any
              card.
            </p>
          </div>

          <div className="mt-12 flex gap-6 overflow-x-auto pb-4 snap-x snap-mandatory md:grid md:grid-cols-3 md:overflow-visible md:pb-0">
            {GIST.map((card) => (
              <div
                key={card.id}
                className="w-[72%] shrink-0 snap-center sm:w-[46%] md:w-auto"
              >
                <FlipCard card={card} />
                <p className="mt-3 text-center text-sm leading-relaxed text-ink/55">
                  {card.line}
                </p>
              </div>
            ))}
          </div>
        </section>

        <section className="mt-16 grid gap-10 md:grid-cols-[0.8fr_1.2fr]">
          <div>
            <h2 className="font-display-light text-3xl sm:text-4xl">
              How the morning runs.
            </h2>
            <p className="mt-3 text-ink/60">
              Five minutes. No slides. The deck does the facilitating.
            </p>
          </div>
          <ol className="space-y-5">
            {[
              ["Gather", "Whole team, before the first client. Phones down. Deck on the bench."],
              ["Turn a card", "One person flips today’s ritual. Wins, priorities, or the stretch."],
              ["Say it out loud", "Everyone answers. The behaviour gets named, not just the sale."],
              ["Repeat for 30 days", "Confidence compounds. The huddle no longer depends on the owner remembering."],
            ].map(([t, d], i) => (
              <li key={t} className="flex gap-5 border-t border-sand pt-5">
                <span className="font-display text-2xl text-blush">0{i + 1}</span>
                <div>
                  <div className="font-display text-xl">{t}</div>
                  <p className="mt-1 text-sm text-ink/60">{d}</p>
                </div>
              </li>
            ))}
          </ol>
        </section>

        <section className="mt-16 overflow-hidden rounded-[2rem] bg-ink text-cream md:grid md:grid-cols-[1.1fr_0.9fr]">
          <div className="p-8 md:p-12">
            <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-blush">
              Pairs with
            </div>
            <h2 className="mt-4 font-display-light text-3xl leading-snug sm:text-4xl">
              The deck keeps what the Accelerator Course starts.
            </h2>
            <p className="mt-4 text-cream/70">
              Sonia installs the system in a day. The cards make the team run it
              every morning after she leaves — and give you something concrete
              to review at the 30-day accountability session.
            </p>
            <button
              onClick={() => navigate("home")}
              className="mt-7 rounded-full bg-blush px-7 py-4 text-sm font-semibold text-ink transition hover:bg-cream"
            >
              See the Accelerator Course →
            </button>
          </div>
          <img
            src={BRAND.workbooks}
            alt="Salon team with Accelerator Course workbooks"
            className="h-64 w-full object-cover md:h-full"
            loading="lazy"
          />
        </section>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-sand bg-cream/95 p-3 backdrop-blur sm:hidden">
        <button
          onClick={() => addToCart(qty)}
          className="block w-full rounded-full bg-ink py-3.5 text-center text-sm font-semibold text-cream"
        >
          Add to bag — {money(DECK.price * qty)}
        </button>
      </div>
    </div>
  );
}

export function CartDrawer() {
  const open = useCartOpen();
  const lines = useCartLines();
  const qty = cartQty(lines);
  const total = cartTotal(lines);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[60]">
      <button
        aria-label="Close bag"
        className="absolute inset-0 bg-ink/50 backdrop-blur-sm"
        onClick={closeCart}
      />
      <aside className="absolute inset-y-0 right-0 flex w-full max-w-md flex-col bg-cream shadow-2xl">
        <div className="flex items-center justify-between border-b border-sand px-6 py-5">
          <h2 className="font-display text-2xl">Your bag</h2>
          <button
            onClick={closeCart}
            className="grid h-9 w-9 place-items-center rounded-full border border-sand"
            aria-label="Close"
          >
            ✕
          </button>
        </div>

        {qty === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center px-8 text-center">
            <img src={BRAND.logo} alt="" className="h-14 w-14 object-contain opacity-80" />
            <p className="mt-4 font-display text-xl">Your bag is empty.</p>
            <p className="mt-2 text-sm text-ink/55">
              The deck is the only thing we sell. On purpose.
            </p>
            <button
              onClick={() => {
                closeCart();
                navigate("product");
              }}
              className="mt-6 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-cream"
            >
              View the deck
            </button>
          </div>
        ) : (
          <>
            <div className="flex-1 overflow-y-auto px-6 py-6">
              <div className="flex gap-4">
                <img
                  src={DECK.sellFront}
                  alt=""
                  className="h-28 w-16 rounded-lg object-cover shadow"
                />
                <div className="flex-1">
                  <div className="font-display text-lg leading-snug">{DECK.name}</div>
                  <div className="mt-1 text-sm text-ink/50">Physical deck · Australia</div>
                  <div className="mt-3 flex items-center justify-between">
                    <Qty value={qty} onChange={setQty} />
                    <div className="font-semibold">{money(total)}</div>
                  </div>
                </div>
              </div>
              <button
                onClick={clearCart}
                className="mt-4 text-xs font-semibold text-ink/40 underline underline-offset-4 hover:text-rose-deep"
              >
                Remove
              </button>
            </div>
            <div className="border-t border-sand px-6 py-5">
              <div className="flex justify-between text-sm text-ink/60">
                <span>Shipping</span>
                <span>Free in Australia</span>
              </div>
              <div className="mt-2 flex justify-between font-display text-xl">
                <span>Total</span>
                <span>{money(total)}</span>
              </div>
              <button
                onClick={() => {
                  closeCart();
                  navigate("checkout");
                }}
                className="mt-5 w-full rounded-full bg-ink py-4 text-sm font-semibold text-cream transition hover:bg-rose hover:text-ink"
              >
                Checkout →
              </button>
            </div>
          </>
        )}
      </aside>
    </div>
  );
}

const STATES = ["NSW", "VIC", "QLD", "SA", "WA", "TAS", "NT", "ACT"];

export function Checkout() {
  const lines = useCartLines();
  const qty = cartQty(lines);
  const total = cartTotal(lines);

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const data = new FormData(e.currentTarget);
    placeOrder({
      name: String(data.get("name") || ""),
      email: String(data.get("email") || ""),
    });
    navigate("thanks");
  };

  if (qty === 0) {
    return (
      <div className="bg-cream">
        <ShopHeader />
        <div className="mx-auto max-w-lg px-5 py-24 text-center">
          <h1 className="font-display text-3xl">Nothing to check out.</h1>
          <button
            onClick={() => navigate("shop")}
            className="mt-6 rounded-full bg-ink px-6 py-3 text-sm font-semibold text-cream"
          >
            Back to the shop
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-cream">
      <ShopHeader />
      <div className="mx-auto grid w-full max-w-6xl gap-10 px-5 py-12 lg:grid-cols-[1.15fr_0.85fr]">
        <form onSubmit={submit} className="space-y-5">
          <button
            type="button"
            onClick={() => navigate("product")}
            className="text-xs font-semibold uppercase tracking-[0.16em] text-ink/45 hover:text-rose-deep"
          >
            ← Back to the deck
          </button>
          <h1 className="font-display-light text-4xl">Checkout</h1>
          <p className="text-sm text-ink/55">
            Ships Australia-wide. You’ll get a confirmation at the email below.
          </p>

          <div className="grid gap-4 sm:grid-cols-2">
            {[
              ["name", "Full name", "text", "Jane Smith", false],
              ["salon", "Salon name", "text", "Luxe Hair Co.", false],
              ["email", "Email", "email", "you@salon.com.au", false],
              ["phone", "Phone", "tel", "04__ ___ ___", false],
            ].map(([name, label, type, ph]) => (
              <label key={String(name)} className="block">
                <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-ink/50">
                  {label}
                </span>
                <input
                  required
                  name={String(name)}
                  type={String(type)}
                  placeholder={String(ph)}
                  className="mt-2 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm outline-none focus:border-rose focus:ring-2 focus:ring-blush/40"
                />
              </label>
            ))}
          </div>

          <label className="block">
            <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-ink/50">
              Street address
            </span>
            <input
              required
              name="address"
              placeholder="12 Chapel Street"
              className="mt-2 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm outline-none focus:border-rose focus:ring-2 focus:ring-blush/40"
            />
          </label>

          <div className="grid gap-4 sm:grid-cols-3">
            <label className="block sm:col-span-1">
              <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-ink/50">
                Suburb
              </span>
              <input
                required
                name="suburb"
                className="mt-2 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm outline-none focus:border-rose focus:ring-2 focus:ring-blush/40"
              />
            </label>
            <label className="block">
              <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-ink/50">
                State
              </span>
              <select
                required
                name="state"
                defaultValue=""
                className="mt-2 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm outline-none focus:border-rose focus:ring-2 focus:ring-blush/40"
              >
                <option value="" disabled>
                  Select…
                </option>
                {STATES.map((s) => (
                  <option key={s}>{s}</option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="text-[11px] font-semibold uppercase tracking-[0.15em] text-ink/50">
                Postcode
              </span>
              <input
                required
                name="postcode"
                inputMode="numeric"
                pattern="[0-9]{4}"
                placeholder="3000"
                className="mt-2 w-full rounded-xl border border-sand bg-white px-4 py-3 text-sm outline-none focus:border-rose focus:ring-2 focus:ring-blush/40"
              />
            </label>
          </div>

          <button
            type="submit"
            className="w-full rounded-full bg-ink py-4 text-sm font-semibold text-cream transition hover:bg-rose hover:text-ink"
          >
            Place order — {money(total)}
          </button>
          <p className="text-center text-xs text-ink/40">
            You’ll be contacted to confirm payment and delivery. No card is charged on this page.
          </p>
        </form>

        <aside className="h-fit rounded-[1.5rem] border border-sand bg-white p-6 lg:sticky lg:top-28">
          <h2 className="font-display text-xl">Order</h2>
          <div className="mt-5 flex gap-4">
            <img src={DECK.sellFront} alt="" className="h-24 w-14 rounded-md object-cover" />
            <div>
              <div className="font-display leading-snug">{DECK.name}</div>
              <div className="mt-1 text-sm text-ink/50">Qty {qty}</div>
              <div className="mt-1 font-semibold">{money(total)}</div>
            </div>
          </div>
          <div className="mt-5 space-y-2 border-t border-sand pt-4 text-sm text-ink/60">
            <div className="flex justify-between">
              <span>Shipping</span>
              <span>Free</span>
            </div>
            <div className="flex justify-between font-display text-lg text-ink">
              <span>Total</span>
              <span>{money(total)}</span>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

export function Thanks() {
  const order = useOrder();
  return (
    <div className="bg-cream">
      <ShopHeader />
      <div className="mx-auto max-w-xl px-5 py-20 text-center">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-rose text-2xl text-ink">
          ✓
        </div>
        <h1 className="mt-6 font-display-light text-4xl">Your deck is confirmed.</h1>
        <p className="mt-4 text-ink/65">
          {order
            ? `${order.name.split(" ")[0]}, order ${order.id} is in. A confirmation is on its way to ${order.email}.`
            : "Your order is in. A confirmation email is on its way."}
        </p>
        {order && (
          <div className="mt-6 rounded-2xl border border-sand bg-white p-5 text-sm text-ink/70">
            <div className="flex justify-between">
              <span>30 Days to Retail Confidence</span>
              <span>× {order.qty}</span>
            </div>
            <div className="mt-2 flex justify-between font-semibold text-ink">
              <span>Paid</span>
              <span>{money(order.total)}</span>
            </div>
          </div>
        )}
        <p className="mt-6 text-sm text-ink/50">
          Most decks arrive in 5–8 business days. Put it on the back bar the morning it lands.
        </p>
        <div className="mt-8 flex flex-wrap justify-center gap-3">
          <button
            onClick={() => navigate("home")}
            className="rounded-full bg-ink px-6 py-3 text-sm font-semibold text-cream"
          >
            Back to the course
          </button>
          <button
            onClick={() => navigate("shop")}
            className="rounded-full border border-ink/20 px-6 py-3 text-sm font-semibold"
          >
            Back to the shop
          </button>
        </div>
      </div>
    </div>
  );
}

export function ShopView({ view }: { view: View }) {
  if (view === "product") return <ProductPage />;
  if (view === "checkout") return <Checkout />;
  if (view === "thanks") return <Thanks />;
  return <ShopHome />;
}

export function DeckTeaser() {
  return (
    <section className="px-5 py-20 md:py-24">
      <div className="mx-auto grid w-full max-w-6xl items-center gap-10 overflow-hidden rounded-[2rem] bg-ink text-cream md:grid-cols-[0.8fr_1.2fr]">
        <div className="flex items-center justify-center bg-rose/15 px-3 py-6">
          <CardSpread compact />
        </div>
        <div className="px-8 pb-12 md:px-12 md:py-14">
          <div className="text-[11px] font-semibold uppercase tracking-[0.22em] text-blush">
            Now in the shop
          </div>
          <h2 className="mt-4 font-display-light text-3xl leading-snug sm:text-4xl">
            The 30 days, in their hands.
          </h2>
          <p className="mt-4 max-w-lg text-cream/70">
            A card a morning. Five minutes. The Daily Huddle, without you having
            to run it. {money(DECK.price)} — one deck for the whole team.
          </p>
          <button
            onClick={() => navigate("product")}
            className="mt-7 rounded-full bg-blush px-7 py-4 text-sm font-semibold text-ink transition hover:bg-cream"
          >
            Shop the deck →
          </button>
        </div>
      </div>
    </section>
  );
}
