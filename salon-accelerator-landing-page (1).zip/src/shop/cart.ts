import { useSyncExternalStore } from "react";
import { DECK } from "./data";

export type CartLine = { id: string; qty: number };
export type Order = {
  id: string;
  email: string;
  name: string;
  qty: number;
  total: number;
};

let lines: CartLine[] = [];
let drawer = false;
let order: Order | null = null;
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}

function subscribe(cb: () => void) {
  listeners.add(cb);
  return () => listeners.delete(cb);
}

export function addToCart(qty = 1) {
  const existing = lines.find((l) => l.id === DECK.id);
  lines = existing
    ? lines.map((l) =>
        l.id === DECK.id ? { ...l, qty: Math.min(10, l.qty + qty) } : l
      )
    : [...lines, { id: DECK.id, qty }];
  drawer = true;
  emit();
}

export function setQty(qty: number) {
  if (qty <= 0) {
    lines = [];
  } else {
    lines = lines.map((l) =>
      l.id === DECK.id ? { ...l, qty: Math.min(10, qty) } : l
    );
    if (!lines.length) lines = [{ id: DECK.id, qty: Math.min(10, qty) }];
  }
  emit();
}

export function clearCart() {
  lines = [];
  emit();
}

export function openCart() {
  drawer = true;
  emit();
}

export function closeCart() {
  drawer = false;
  emit();
}

export function placeOrder(details: { email: string; name: string }) {
  const qty = lines.reduce((n, l) => n + l.qty, 0) || 1;
  order = {
    id: "SD-" + Date.now().toString().slice(-6),
    email: details.email,
    name: details.name,
    qty,
    total: qty * DECK.price,
  };
  lines = [];
  drawer = false;
  emit();
  return order;
}

export function useCartLines() {
  return useSyncExternalStore(subscribe, () => lines, () => lines);
}

export function useCartOpen() {
  return useSyncExternalStore(subscribe, () => drawer, () => false);
}

export function useOrder() {
  return useSyncExternalStore(subscribe, () => order, () => null);
}

export function cartQty(linesNow: CartLine[] = lines) {
  return linesNow.reduce((n, l) => n + l.qty, 0);
}

export function cartTotal(linesNow: CartLine[] = lines) {
  return cartQty(linesNow) * DECK.price;
}
