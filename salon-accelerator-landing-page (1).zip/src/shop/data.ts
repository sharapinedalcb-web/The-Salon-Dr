import { back35, back36, back37, front35, front36, front37 } from "./cards";

export const DECK = {
  id: "30-days-retail-confidence",
  name: "30 Days to Retail Confidence",
  price: 89,
  /** The one front shown on the shop listing and as the product photo. */
  sellFront: front36,
  sellFrontName: "Today’s Three Priorities",
  tagline: "The daily card deck for the salon floor.",
  blurb:
    "One card. Five minutes. Every morning, before the first client sits down. The Daily Huddle, in their hands — so retail confidence doesn’t depend on you reminding anyone.",
};

export type DeckCard = {
  id: string;
  name: string;
  front: string;
  back: string;
  prompt: string;
  line: string;
};

/** A gist of the deck — three rituals, front and back. */
export const GIST: DeckCard[] = [
  {
    id: "wins",
    name: "Three Wins",
    front: front35,
    back: back35,
    prompt: "Share three wins from yesterday.",
    line: "Big or small. Celebrate the behaviour that created the win, not just the outcome.",
  },
  {
    id: "priorities",
    name: "Today’s Three Priorities",
    front: front36,
    back: back36,
    prompt: "What are the three most important things you will focus on today?",
    line: "Focus creates momentum. Three things. Then the door opens.",
  },
  {
    id: "challenge",
    name: "Today’s Challenge",
    front: front37,
    back: back37,
    prompt: "What’s one challenge you’ll commit to today?",
    line: "Choose something that stretches you. Growth lives just outside the comfort zone.",
  },
];

export const money = (n: number) =>
  n.toLocaleString("en-AU", {
    style: "currency",
    currency: "AUD",
    minimumFractionDigits: 0,
  });
