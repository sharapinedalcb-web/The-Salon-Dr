import { useSyncExternalStore } from "react";

export type View = "home" | "shop" | "product" | "checkout" | "thanks";

let view: View = "home";
const listeners = new Set<() => void>();

function emit() {
  listeners.forEach((l) => l());
}

export function navigate(next: View) {
  view = next;
  if (typeof window !== "undefined") window.scrollTo(0, 0);
  emit();
}

export function useView() {
  return useSyncExternalStore(
    (cb) => {
      listeners.add(cb);
      return () => listeners.delete(cb);
    },
    () => view,
    () => "home" as View
  );
}
